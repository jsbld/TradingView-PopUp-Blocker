// TradingView Popup Blocker v1.1
// - Finds promo popups by text patterns AND by the little "AD" badge.
// - Looks inside shadow DOM (open or closed) and inside every frame on tradingview.com.
// - Does not rely on position:fixed; uses size + text length to pick the popup box.

const AD_PATTERNS = [
  /start earning now/i,
  /referral rewards/i,
  /earn \$\d+ for each friend/i,
  /cash out with/i,
  /refer a friend/i,
  /time to upgrade\?/i,
  /explore our plans/i,
  /more tools and data you have/i,
  /black friday|cyber monday/i,
];

const MAX_TEXT = 600;   // popups have little text
const MAX_W = 700;      // and are small
const MAX_H = 400;
const MIN_BADGE_W = 250; // popup carrying an "AD" badge is at least this big
const MIN_BADGE_H = 70;  // (keeps watchlist rows etc. safe)

function shadowOf(el) {
  try {
    if (typeof chrome !== "undefined" && chrome.dom && chrome.dom.openOrClosedShadowRoot) {
      return chrome.dom.openOrClosedShadowRoot(el) || el.shadowRoot;
    }
  } catch (e) {}
  return el.shadowRoot;
}

function parentOf(n) {
  if (n.parentElement) return n.parentElement;
  const root = n.getRootNode && n.getRootNode();
  return root && root.host ? root.host : null;
}

// Climb to the biggest ancestor that still looks like a small popup box.
function popupContainer(start) {
  let node = start, best = null;
  while (node && node !== document.body && node !== document.documentElement) {
    if ((node.textContent || "").length > MAX_TEXT) break;
    const r = node.getBoundingClientRect();
    if (r.width > MAX_W || r.height > MAX_H) break;
    best = node;
    node = parentOf(node);
  }
  return best;
}

function hide(el) {
  if (!el || el.dataset.tvBlocked) return;
  el.dataset.tvBlocked = "1";
  el.style.setProperty("display", "none", "important");
  console.debug("[TV Popup Blocker] hid:", el);
}

function checkText(textNode) {
  const text = textNode.nodeValue || "";
  const parent = textNode.parentElement;
  if (!parent || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(parent.tagName)) return;

  if (AD_PATTERNS.some((re) => re.test(text))) {
    hide(popupContainer(parent));
  } else if (text.trim() === "AD") {
    const box = popupContainer(parent);
    if (box) {
      const r = box.getBoundingClientRect();
      if (r.width >= MIN_BADGE_W && r.height >= MIN_BADGE_H) hide(box);
    }
  }
}

// Ads served from another website live in an iframe whose text we can't read,
// but the iframe element itself is visible. Hide small iframes sitting in the
// bottom-left corner of the page (where these popups appear).
function checkIframe(f) {
  if (window !== window.top || f.dataset.tvBlocked) return;
  const r = f.getBoundingClientRect();
  const small = r.width >= 200 && r.width <= 700 && r.height >= 80 && r.height <= 350;
  const bottomLeft = r.left < 300 && r.bottom > window.innerHeight - 250;
  if (small && bottomLeft) hide(popupContainer(f) || f);
}

const observed = new WeakSet();

function scan(root) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT);
  let n;
  while ((n = walker.nextNode())) {
    if (n.nodeType === Node.TEXT_NODE) {
      checkText(n);
    } else {
      if (n.tagName === "IFRAME") checkIframe(n);
      const sr = shadowOf(n);
      if (sr) {
        scan(sr);
        watch(sr);
      }
    }
  }
}

let pending = false;
function scheduleScan() {
  if (pending) return;
  pending = true;
  requestAnimationFrame(() => {
    pending = false;
    scan(document);
  });
}

function watch(root) {
  if (observed.has(root)) return;
  observed.add(root);
  new MutationObserver(scheduleScan).observe(root, { childList: true, subtree: true, characterData: true });
}

console.log("[TV Popup Blocker] v1.2 active in", location.href);
scan(document);
watch(document);
// Safety net for anything the observers miss (e.g. popups that become visible later).
setInterval(() => scan(document), 1500);
